module.exports = function(grunt) {
  return {
    target: ['src/js/intlTelInput.js']
  };
};
